About
=====

KivMob is an open source project not associated with AdMob. Please abide by their policies when designing and testing your application.

https://support.google.com/admob/answer/6128543?hl=en



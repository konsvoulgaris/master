Resources
=========

AdMob
------------------------
* Ad Units & Formats: https://support.google.com/admob/answer/6128738?hl=en&ref_topic=7382891
* Google Group: https://groups.google.com/forum/#!forum/google-admob-ads-sdk
* Policies: https://support.google.com/admob/answer/6128543?hl=en

Kivy
------------------------
* Documentation: https://kivy.org/doc/stable/
* Python for Android (p4a): https://github.com/kivy/python-for-android
* Support Kivy: https://opencollective.com/kivy

Additional Libraries
------------------------
* KivyMD: https://gitlab.com/kivymd/KivyMD